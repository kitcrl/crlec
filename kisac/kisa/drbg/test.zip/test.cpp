// test.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"

BOOL CALLBACK MainDlgProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

BOOL Listen();
BOOL Connect();
BOOL Send();
BOOL Close();

static UINT _stdcall listenThread(LPVOID lParam);
static UINT _stdcall reciveThread(LPVOID lParam);


HANDLE				lThreadID;
HANDLE				rThreadID;

HWND				m_hWnd;

WSADATA				wsaData;

SOCKET				hClntSock;
SOCKADDR_IN			clntAddr;

WSAEVENT            events[1];
WSAEVENT			newEvt;
WSANETWORKEVENTS	netEvts;
WSAEVENT			m_evenListen;
WSAEVENT			m_evenConnect;
WSAEVENT			m_evenRecive;
WSAEVENT			m_evListenshutdown;
WSAEVENT			m_evReciveshutdown;

char *m_pcIP;
char *m_pcPORT;
char m_Name[20];

HWND g_hDlg;
HINSTANCE g_hInst;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	g_hInst = hInstance;
	
	DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG1), HWND_DESKTOP, MainDlgProc);
	
	return 0;
}

BOOL CALLBACK MainDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		g_hDlg = hDlg;
		SetDlgItemText(hDlg, IDC_IP, "127.0.0.1");
		SetDlgItemText(hDlg, IDC_PORT, "9190");
		
		EnableWindow(GetDlgItem(hDlg, IDC_SERV),TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_CLNT),TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_SEND),FALSE);
		
		if (WSAStartup(MAKEWORD(2,2),&wsaData) != 0)
			MessageBox(NULL, "WSAStartup error!!", "error",MB_OK);
		return 0;
		
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_SERV:
			SetWindowText(hDlg, "server");
			strcpy(m_Name, "Server : ");
			SetDlgItemText(hDlg, IDC_MSG, " ���� ��û�� ��ٸ��ϴ�.");
			EnableWindow(GetDlgItem(hDlg, IDC_SERV),FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_CLNT),FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_SEND),TRUE);

			Listen();
			break;
		case IDC_CLNT:
			SetWindowText(hDlg, "client");
			strcpy(m_Name, "Client : ");
			SetDlgItemText(hDlg, IDC_MSG, " �����ϰ� �ֽ��ϴ�..");
			EnableWindow(GetDlgItem(hDlg, IDC_SERV),FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_CLNT),FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_SEND),TRUE);
			Connect();
			break;
		case IDC_SEND:
			Send();
			break;
		case IDC_CLOSE:
			EnableWindow(GetDlgItem(hDlg, IDC_SERV),TRUE);
			EnableWindow(GetDlgItem(hDlg, IDC_CLNT),TRUE);
			EnableWindow(GetDlgItem(hDlg, IDC_SEND),FALSE);
			Close();
			break;
		case IDOK:
			Close();
			EndDialog(hDlg,0);

			break;
		}
		return false;
	}
	return false;
}

BOOL Listen()
{
	HANDLE hListenThread;
	UINT   iListenThreadID;
	
	m_evenListen = CreateEvent(NULL, FALSE, FALSE, NULL);
	
	hListenThread = (HANDLE)_beginthreadex(NULL, 0, listenThread, g_hDlg, 0, &iListenThreadID);
	if(!hListenThread)
	{
		MessageBox(NULL, "������ ���� ����.","������",MB_OK);
		return FALSE;
	}
	
	return TRUE;
}

UINT _stdcall listenThread(LPVOID lParam)
{
	HANDLE rThreadID;
	UINT   iReciveThreadID;
	
	SOCKET				s;				// Main Listen Socket
	SOCKET				cs;				// client socket
	struct sockaddr_in	addr;
	sockaddr			caddr;
	int					caddrlen = sizeof(sockaddr);
	int					iRet;
	
	WSAEVENT			events[2];
	WSAEVENT			ev;
	WSANETWORKEVENTS	evNetwork;
	int					nAccept = 0;
	const int			opt = 1;
	
	s = WSASocket(AF_INET, SOCK_STREAM, 0, (LPWSAPROTOCOL_INFO)NULL, 0, WSA_FLAG_OVERLAPPED);
	if(s == INVALID_SOCKET)
	{
		MessageBox(NULL, "���� ���� ����.","����",MB_OK);
		Close();
		return 0;
	}
	
	if(setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) == SOCKET_ERROR)
	{
		closesocket(s);
		Close();
		return 0; 
	}
	
	setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (char *)&opt, sizeof(opt));
	
	char port[6];
	GetDlgItemText(g_hDlg, IDC_PORT, port, 6);
	
	addr.sin_family		= AF_INET;
	addr.sin_port		= htons(atoi(port));
	addr.sin_addr.s_addr = INADDR_ANY;
	
	iRet = bind(s, (struct sockaddr *)&addr, sizeof(addr));
	if(iRet == SOCKET_ERROR)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ������� �ʾҽ��ϴ�.");
		Close();
		return 0;
	}	
	
	iRet = listen(s, SOMAXCONN);
	if(iRet == SOCKET_ERROR)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ������� �ʾҽ��ϴ�.");
		Close();
		return 0;
	}	
	
	m_evListenshutdown = WSACreateEvent();
	if(m_evListenshutdown == WSA_INVALID_EVENT)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
		Close();
		return 0;
	}
	
	ev = WSACreateEvent();
	if(ev == WSA_INVALID_EVENT)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
		Close();
		return 0;
	}
	
	iRet = WSAEventSelect(s, ev, FD_ACCEPT);
	if(iRet == SOCKET_ERROR)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
		Close();
		return 0;
	}
	
	events[0] = m_evListenshutdown;
	events[1] = ev;
	
	SetEvent(m_evenListen);
	
	while(TRUE)
	{
		DWORD dwRet = WSAWaitForMultipleEvents(2, events, FALSE, WSA_INFINITE, FALSE);
		
		if(dwRet == WAIT_FAILED || dwRet == WAIT_OBJECT_0)
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
			Close();
			return 0;
		}
		
		iRet = WSAEnumNetworkEvents(s, ev, &evNetwork);
		if(iRet == SOCKET_ERROR)						 
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
			Close();
			return 0;
		}
		
		if(evNetwork.lNetworkEvents & FD_ACCEPT)
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.\r\n");
			
			cs = WSAAccept(s, &caddr, &caddrlen, NULL, NULL);
			if(cs == INVALID_SOCKET)
			{
				SetDlgItemText(g_hDlg, IDC_MSG, " ���� ���� �Ǿ����ϴ�.");
				Close();
			}
			hClntSock = cs;
			
			rThreadID = (HANDLE) _beginthreadex(NULL, 0, reciveThread, g_hDlg, 0, &iReciveThreadID);

		}
	}
	
	SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
	Close();
	return TRUE; 
}

UINT _stdcall reciveThread(LPVOID lParam)
{
	SOCKET s = hClntSock;
	
	WSAEVENT			events[2];
	WSAEVENT			ev;
	WSANETWORKEVENTS	evNetwork;
	
	char   pcBuffer[10240];
	DWORD  dwFlags = 0;
	int    iRet;
	memset(pcBuffer, 0, 10240);
	
	m_evReciveshutdown = WSACreateEvent();
	
	ev = WSACreateEvent();
	if(ev == WSA_INVALID_EVENT)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
		Close();
		return 0;
	}
	
	iRet = WSAEventSelect(s, ev, FD_READ|FD_CLOSE);
	if(iRet == SOCKET_ERROR)
	{
		SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
		Close();
		return 0;
	}
	
	events[0] = m_evReciveshutdown;
	events[1] = ev;
	
	SetEvent(m_evenListen);
	
	while(TRUE)
	{
		DWORD dwRet = WSAWaitForMultipleEvents(2, events, FALSE, WSA_INFINITE, FALSE);
		
		if(dwRet == WAIT_FAILED || dwRet == WAIT_OBJECT_0)
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
			Close();
			return 0;
		}
		
		iRet = WSAEnumNetworkEvents(s, ev, &evNetwork);
		if(iRet == SOCKET_ERROR)						 
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
			Close();
			return 0;
		}
		
		if(evNetwork.lNetworkEvents & FD_READ)
		{
			char buf[256];
			recv(s,  buf,	256, 0);
			GetDlgItemText(g_hDlg,IDC_MSG, pcBuffer,10240);
			strcat(pcBuffer, buf);
			SetDlgItemText(g_hDlg, IDC_MSG, pcBuffer);
		}
		
		if(evNetwork.lNetworkEvents & FD_CLOSE)
		{
			SetDlgItemText(g_hDlg, IDC_MSG, " ����Ǿ����ϴ�.");
			Close();
			SetWindowText(g_hDlg, "Thread ��,.��");
		}
	}
	return TRUE;
}

BOOL Connect()
{
	hClntSock = socket(AF_INET, SOCK_STREAM, 0);
	
	char ip[16], port[10];
	GetDlgItemText(g_hDlg, IDC_IP, ip, 16);
	GetDlgItemText(g_hDlg, IDC_PORT, port, 10);
	
	clntAddr.sin_family = AF_INET;
	clntAddr.sin_addr.s_addr = inet_addr(ip);
	clntAddr.sin_port = htons(atoi(port));
	
	bind(hClntSock, (sockaddr *)&clntAddr, sizeof(clntAddr));
	
	connect(hClntSock, (sockaddr *)&clntAddr, sizeof(clntAddr));
	
	SetDlgItemText(g_hDlg, IDC_MSG, " ���� �Ǿ����ϴ�..\r\n");
	UINT iReciveThreadID;
	rThreadID = (HANDLE) _beginthreadex(NULL, 0, reciveThread, g_hDlg, 0, &iReciveThreadID);
	return TRUE;
}

BOOL Send()
{
	char buf[128],name[20], Msg[10240], temp[256];
	strcpy(buf, "");
	strcpy(name, m_Name);
	GetDlgItemText(g_hDlg, IDC_INPUT, buf, 128);
	strcpy(temp, name);
	strcat(temp, buf);
	strcat(temp, "\r\n");
	send(hClntSock, temp, 256, 0);
	GetDlgItemText(g_hDlg, IDC_MSG, Msg, 10240);
	strcat(Msg, temp);
	SetDlgItemText(g_hDlg, IDC_MSG, Msg);
	SetDlgItemText(g_hDlg, IDC_INPUT, "");
	return TRUE;
}

BOOL Close()
{
	WSACleanup();
	closesocket(hClntSock);
	SetWindowText(g_hDlg," Thread.....");
	SetDlgItemText(g_hDlg, IDC_MSG, "����Ǿ����ϴ�.");
	
	return TRUE;
}